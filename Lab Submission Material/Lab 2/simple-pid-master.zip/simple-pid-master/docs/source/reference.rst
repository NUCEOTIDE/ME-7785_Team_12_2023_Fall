
API reference
=============

This library consists of only one class, ``PID``, which you make an instance of and use. It's full API documentation is given below.


simple_pid.PID
--------------

.. automodule:: simple_pid.pid
   :members:
   :undoc-members:
