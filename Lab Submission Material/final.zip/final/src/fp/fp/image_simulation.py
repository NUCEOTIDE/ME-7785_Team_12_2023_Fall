import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool
from sensor_msgs.msg import CompressedImage
from cv_bridge import CvBridge
import cv2
import os
import random


class image_simulation(Node):
    def __init__(self):
        super().__init__('image_simulation')
        self.image_publisher = self.create_publisher(CompressedImage, '/image_raw/compressed', 10)
        self.need_publisher = self.create_publisher(Bool, 'need_prediction', 10)
        self.create_timer(0.1, self.timer_callback)
        self.root = '2023Fimgs'
        self.image_list = os.listdir(self.root)
        self.index = 0

    def timer_callback(self):
        img_file = self.image_list[self.index]
        if not img_file[-3:] == 'txt':
            path = os.path.join(self.root, img_file)
            img = cv2.imread(path)
            msg = CvBridge().cv2_to_compressed_imgmsg(img)
            self.get_logger().info(img_file)
            self.image_publisher.publish(msg)

            # p = random.randint(0,1)
            p = 1
            need_msg = Bool()
            if p:
                need_msg.data = True
                self.need_publisher.publish(need_msg)
            else:
                need_msg.data = False
                self.need_publisher.publish(need_msg)

        self.index = (self.index + 1) % len(self.image_list)


def main():
    rclpy.init()
    sim_node = image_simulation()
    rclpy.spin(sim_node)
    sim_node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
