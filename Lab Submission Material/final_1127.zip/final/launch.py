from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # Node(
        #     package='fp',
        #     executable='cropper',
        #     name='crop_image'
        # ),
        Node(
            package='fp',
            executable='shower',
            name='image_show'
        ),
        Node(
            package='fp',
            executable='predictor',
            name='sign_keep_predict'
        ),
    ])
