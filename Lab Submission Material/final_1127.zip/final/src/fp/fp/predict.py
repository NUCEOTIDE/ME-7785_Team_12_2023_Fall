import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool, UInt8MultiArray, Int16

import numpy as np
import cv2
import torch
import torch.nn as nn

class nn_model(nn.Module):
    def __init__(self):
        super(nn_model,self).__init__()
        self.act = nn.LeakyReLU()
        self.conv1 = nn.Conv2d(in_channels=3, out_channels=10, kernel_size=(5,5), stride=(2,2))
        self.maxpool = nn.MaxPool2d(kernel_size=2)
        self.conv2 = nn.Conv2d(in_channels=10, out_channels=20, kernel_size=(5,5),stride=(2,2))
        self.fc = nn.Linear(in_features=500, out_features=5)

    def forward(self, data):
        batch_size = data.size()[0]
        x = self.conv1(data)
        x = self.act(x)
        x = self.maxpool(x)
        x = self.conv2(x)
        x = self.act(x)
        x = self.maxpool(x)
        x = x.view(batch_size,-1)
        x = self.fc(x)
        return x



# model_name = 'cnn_23.pth'
# device = 'cpu'
# model = torch.load(model_name).to(device)

class sign_predict(Node):
    def __init__(self, preload_model=None):
        super().__init__('sign_predict')
        self.__need_prediction_subscriber = self.create_subscription(Bool, 'need_prediction', self.prediction, 10)
        self.__crop_result_subscriber = self.create_subscription(UInt8MultiArray, 'crop_result', self.cropped_image_callback, 10)
        self.__prediction_result_publisher = self.create_publisher(Int16, 'prediction_result', 10)
        self.cropped_image = None
        self.cropped_result = None
        # model file name
        self.model_name = 'cnn_23_sta.pth'
        self.device = 'cpu'
        self.model = nn_model()
        self.model.load_state_dict(torch.load(self.model_name))
        # self.model = preload_model
        self.get_logger().info('Predicter is ready.')


    def cropped_image_callback(self, msg):
        cropped_image_array = msg.data[:-1]
        cropped_result = msg.data[-1]

        # cropped image is not None
        if cropped_result:
            self.cropped_result = True
        # cropped image is None
        else:
            self.cropped_result = False
        self.cropped_image = np.array(cropped_image_array).reshape((100, 100, 3))

    def prediction(self, msg):
        need_prediction = msg.data
        prediction_result = Int16()
        # prediction needed at this time
        if need_prediction:
            self.get_logger().info('need')
            # cropped is not None, run the model
            if self.cropped_result:
                numpy_image = np.array(cv2.split(self.cropped_image))
                torch_image = torch.from_numpy(numpy_image)
                input = torch.unsqueeze(torch_image, 0).to(torch.float32)

                # get model output
                output = self.model.forward(input)
                label = torch.argmax(output).item() + 1
                prediction_result.data = label
            # croppped is None
            else:
                prediction_result.data = 0
        # prediciton not needed at this time
        else:
            self.get_logger().info('not need')
            prediction_result.data = -1

        self.__prediction_result_publisher.publish(prediction_result)
        if self.cropped_image is not None:
            cv2.imshow('predict image', self.cropped_image)
            cv2.waitKey(1)

def main():
    p = torch.load('cnn_23_sta.pth')

    rclpy.init()
    predict_node = sign_predict(nn_model().load_state_dict(p))
    rclpy.spin(predict_node)
    predict_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

