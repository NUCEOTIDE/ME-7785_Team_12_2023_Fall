from setuptools import find_packages, setup

package_name = 'fp'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='hanyao',
    maintainer_email='hanyao@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
        'simulator = fp.image_simulation:main',
        'predictor = fp.keep_predict:main',
        'shower = fp.image_show:main',
        'cropper = fp.crop_image:main',
        'sampler = fp.sample_image:main',
        'test_controller = fp.test_controller:main',
        'goal_setter = fp.setting_goal:main'
        ],
    },
)
