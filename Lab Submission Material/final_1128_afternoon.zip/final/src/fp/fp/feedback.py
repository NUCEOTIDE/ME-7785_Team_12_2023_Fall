import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped, PoseStamped, Quaternion
from std_msgs.msg import Int8

import numpy as np
import time

class feedback(Node):
    def __init__(self):
        super().__init__('feedback')

        # subscribe to and update goals
        self.goal_subscriber = self.create_subscription(PoseStamped, '/goal_pose', self.goal_callback, 10)
        # subscriber to and update current condition
        self.amcl_subscriber = self.create_subscription(PoseWithCovarianceStamped, 'amcl_pose', self.amcl_callback, 10)
        # check whether the robot is moving
        self.timer = self.create_timer(2.0, self.timer_callback)
        # publish whether the goal is reached. 0: not yet reached, 1: reached, -1: almost reached but no longer moved, -2: not yet reached and not moving
        self.reach_pubisher = self.create_publisher(Int8, 'feedback', 10)
        # goal, current, and previous conditions
        self.goal_x = None
        self.goal_y = None
        self.goal_yaw = None
        self.current_x = None
        self.current_y = None
        self.current_yaw = None
        self.previous_x = None
        self.previous_y = None
        self.previous_yaw = None
        # distances
        self.linear_distance = None
        self.angular_distance = None
        # acceptable magin
        self.distance_margin = 0.1
        self.yaw_margin = 0.17
        self.distance_tolerate_margin = 0.25
        self.yaw_tolerate_margin = 0.42
        self.minimum_movement = 0.05
        self.minimum_rotation = 0.08

    def quaternion2yaw(self, q):
        return np.arctan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))

    # converting yaw to quaternion, input is radian, return a Pose message
    def yaw2quaternion(self, yaw):
        result = Quaternion()
        result.x = 0.0
        result.y = 0.0
        result.z = np.sin(yaw / 2)
        result.w = np.cos(yaw / 2)
        return result

    def goal_callback(self, msg):
        self.goal_x = msg.pose.position.x
        self.goal_y = msg.pose.position.y
        self.goal_yaw = self.quaternion2yaw(msg.pose.orientation)

        # clear all the previous data when a new goal comes in
        self.previous_x = None
        self.previous_y = None
        self.previous_yaw = None

    def amcl_callback(self, msg):
        self.current_x = msg.pose.pose.position.x
        self.current_y = msg.pose.pose.position.y
        self.current_yaw = self.quaternion2yaw(msg.pose.pose.orientation)

        # a goal has been set
        if self.goal_x is not None:
            self.linear_distance = np.sqrt((self.current_x - self.goal_x) ** 2 + (self.current_y - self.goal_y) ** 2)
            self.angular_distance = np.abs(self.current_yaw - self.goal_yaw)
            self.get_logger().info('linear distance:' + str(self.linear_distance))
            self.get_logger().info('angular distance:' + str(self.angular_distance))

            linear_reach = self.linear_distance <= self.distance_margin
            angular_reach = self.angular_distance <= self.yaw_margin

            msg = Int8()
            # the goal has been reached
            if linear_reach and angular_reach:
                msg.data = 1
                self.get_logger().info('Robot has reached the goal.')
            # not yet reached
            else:
                msg.data = 0
            self.reach_pubisher.publish(msg)


    def timer_callback(self):
        if self.current_x is not None:

            # a goal has been set
            if self.goal_x is not None:

                # the robot has been moving for a while
                if self.previous_x is not None:
                    linear_progress_across_time = np.sqrt((self.current_x - self.previous_x) ** 2 + (self.current_y - self.previous_y) ** 2)
                    angular_progress_across_time = np.abs(self.current_yaw - self.goal_yaw)
                    linear_criterion = linear_progress_across_time < self.minimum_movement
                    angular_criterion = angular_progress_across_time < self.minimum_rotation

                    # in the last time period, the robot did not move at all
                    if linear_criterion and angular_criterion:
                        linear_tolerate_reach = self.linear_distance <= self.distance_tolerate_margin
                        angular_tolerate_reach = self.angular_distance <= self.yaw_tolerate_margin
                        msg = Int8()
                        # the robot has already reached the goal in navigation, but not close enough to our local settings
                        if linear_tolerate_reach and angular_tolerate_reach:
                            msg.data = -1
                            self.get_logger().info('Robot has already reached the goal according to navigation, keep going.')
                        # the robot has not reached the goal but still stopped
                        else:
                            msg.data = -2
                            self.get_logger().info('Robot gets stuck.')

                        self.reach_pubisher.publish(msg)

                # update previous conditions
                self.previous_x = self.current_x
                self.previous_y = self.current_y
                self.previous_yaw = self.current_yaw
                
def main():
    rclpy.init()
    node = feedback()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
