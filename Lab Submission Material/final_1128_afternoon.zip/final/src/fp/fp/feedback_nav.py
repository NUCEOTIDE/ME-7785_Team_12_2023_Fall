import rclpy
from rclpy.node import Node

from nav2_msgs.action._navigate_to_pose import NavigateToPose_FeedbackMessage

class feedback_nav(Node):
    def __init__(self):
        super().__init__('feedback_nav')
        self.sub = self.create_subscription(NavigateToPose_FeedbackMessage, '/navigate_to_pose/_action/feedback', self.feedback_callback, 10)

    def feedback_callback(self, msg):
        print(msg.feedback.estimated_time_remaining)

def main():
    rclpy.init()
    node = feedback_nav()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

        