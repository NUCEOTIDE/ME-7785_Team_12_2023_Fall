import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point, Quaternion, PoseStamped
from std_msgs.msg import Int8

import numpy as np


class setting_goal(Node):
    def __init__(self):
        super().__init__('setting_goal')
        # navigation parameters
        self.map_name = 'map'
        # global map parameters
        self.map = [
            # row 1, y = 0
            [
                {'coordinate': (0, 0), 'accessibility': True, 'judging_orientation': [0, 3]},
                {'coordinate': (1, 0), 'accessibility': True, 'judging_orientation': [0, 1, 2]},
                {'coordinate': (2, 0), 'accessibility': True, 'judging_orientation': [0, 3]},
                {'coordinate': (3, 0), 'accessibility': True, 'judging_orientation': [0, 1]},
                {'coordinate': (4, 0), 'accessibility': True, 'judging_orientation': [0, 3]},
                {'coordinate': (5, 0), 'accessibility': True, 'judging_orientation': [0, 1]},
            ],
            # row 2, y = 1
            [
                {'coordinate': (0, 1), 'accessibility': True, 'judging_orientation': [2, 3]},
                {'coordinate': (1, 1), 'accessibility': True, 'judging_orientation': [0]},
                {'coordinate': (2, 1), 'accessibility': True, 'judging_orientation': [1]},
                {'coordinate': (3, 1), 'accessibility': True, 'judging_orientation': [3]},
                {'coordinate': (4, 1), 'accessibility': True, 'judging_orientation': [2]},
                {'coordinate': (5, 1), 'accessibility': True, 'judging_orientation': [1]},
            ],
            # row 3, y = 2
            [
                {'coordinate': (0, 2), 'accessibility': False},
                {'coordinate': (1, 2), 'accessibility': True, 'judging_orientation': [2, 3]},
                {'coordinate': (2, 2), 'accessibility': True, 'judging_orientation': [1, 2]},
                {'coordinate': (3, 2), 'accessibility': True, 'judging_orientation': [2, 3]},
                {'coordinate': (4, 2), 'accessibility': True, 'judging_orientation': [0, 2]},
                {'coordinate': (5, 2), 'accessibility': True, 'judging_orientation': [1, 2]},
            ],
        ]
        # physical world parameters
        self.edge_length = 0.91
        self.current_goal = None
        # real-time parameters
        self.sign = None
        # publishers and subscribers
        self.test_subscriber = self.create_subscription(Point, 'manual_set_goal', self.test_callback, 10)
        self.goal_publisher = self.create_publisher(PoseStamped, '/goal_pose', 10)
        self.sign_subscriber = self.create_subscription(Int8, 'prediction_result', self.sign_callback, 10)

    # converting quaternion to yaw, input is Quaternion message, return radian
    def quaternion2yaw(self, q):
        return  np.arctan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))

    # converting yaw to quaternion, input is radian, return a Pose message
    def yaw2quaternion(self, yaw):
        result = Quaternion()
        result.x = 0.0
        result.y = 0.0
        result.z = np.sin(yaw / 2)
        result.w = np.cos(yaw / 2)
        return result




    # translating coordinates and orientation to PoseStamped message
    def set_goal(self, x, y, orientation):
        msg = PoseStamped()
        msg.header.frame_id = self.map_name
        # translating x and y to physical coordinates
        point = Point()
        point.x = x * self.edge_length + 0.5 * self.edge_length + 0.3
        point.y = y * self.edge_length + 0.5 * self.edge_length + 0.4
        point.z = 0.0
        # translating orientation to quaternion
        yaw = orientation * np.pi / 2
        quaternion = self.yaw2quaternion(yaw)

        msg.pose.position = point
        msg.pose.orientation = quaternion

        return msg

    def test_callback(self, msg):
        x = msg.x
        y = msg.y
        orientation = msg.z
        goal_msg = self.set_goal(x,y,orientation)
        print(goal_msg)
        self.goal_publisher.publish(goal_msg)

    def sign_callback(self, msg):
        self.sign = msg.data




def main():
    rclpy.init()
    node = setting_goal()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

