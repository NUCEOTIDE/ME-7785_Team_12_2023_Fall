from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='fp',
            executable='goal_setter',
            name='setting_goal'
        ),
        # Node(
        #     package='fp',
        #     executable='test_controller',
        #     name='test_controller'
        # ),
        Node(
            package='fp',
            executable='feedback',
            name='test_controller'
        ),
        Node(
            package='fp',
            executable='conditional_predictor',
            name='sign_keep_predict'
        ),
    ])
