import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy, QoSHistoryPolicy
from cv_bridge import CvBridge
import cv2


class image_show_node(Node):
    def __init__(self):
        super().__init__('image_show')
        image_qos_profile = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history=QoSHistoryPolicy.KEEP_LAST,
            durability=QoSDurabilityPolicy.VOLATILE,
            depth=1
        )
        self.image_subscriber = self.create_subscription(CompressedImage, '/image_raw/compressed', self.image_callback,
                                                         image_qos_profile)
        self.crop_subscriber = self.create_subscription(CompressedImage, 'cropped_image', self.crop_callback, 10)

    def image_callback(self, msg):
        # self.get_logger().info('image get')
        image = CvBridge().compressed_imgmsg_to_cv2(msg, 'bgr8', )
        cv2.imshow('Original Image', image)
        cv2.waitKey(1)

    def crop_callback(self, msg):
        # self.get_logger().info('crop get')
        image = CvBridge().compressed_imgmsg_to_cv2(msg, 'bgr8', )
        cv2.imshow('Cropped Image', image)
        cv2.waitKey(1)


def main():
    rclpy.init()
    image_show = image_show_node()
    rclpy.spin(image_show)
    image_show.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
