import numpy as np
print(np.arctan2(0,-1) / np.pi * 180)