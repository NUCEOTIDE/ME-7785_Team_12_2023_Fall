import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage
from geometry_msgs.msg import Point
from cv_bridge import CvBridge
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy, QoSHistoryPolicy
import numpy as np
import cv2
import os

class sample_image_node(Node):
    def __init__(self):
        super().__init__('sample_image')
        image_qos_profile = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history=QoSHistoryPolicy.KEEP_LAST,
            durability=QoSDurabilityPolicy.VOLATILE,
            depth=1
        )
        self.image_subscriber = self.create_subscription(CompressedImage, 'image_raw/compressed', self.image_callback, image_qos_profile)
        self.control_subscriber = self.create_subscription(Point, 'manual_set_goal', self.control_callback, 10)
        self.root = 'sampled_images'
        self.img = None
        if os.path.exists(self.root):
            self.index = len(os.listdir(self.root))
        else:
            os.mkdir(self.root)
            self.index = 0

    def control_callback(self, msg):
        name = str(self.index) + '.jpg'
        path = os.path.join(self.root, name)
        cv2.imwrite(path, self.img)
        self.index += 1

    def image_callback(self, msg):
        image = CvBridge().compressed_imgmsg_to_cv2(msg, 'bgr8')
        self.img = image
        cv2.imshow('sampler', image)
        cv2.waitKey(1)

def main():
    rclpy.init()
    sample_node = sample_image_node()
    rclpy.spin(sample_node)
    sample_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()




