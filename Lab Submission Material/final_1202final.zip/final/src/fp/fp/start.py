import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped, PoseStamped, Quaternion, PointStamped, Point

import numpy as np

class initiater(Node):
    def __init__(self):
        super().__init__('initiater')
        self.amcl_subscriber = self.create_subscription(PoseWithCovarianceStamped, 'amcl_pose', self.amcl_callback, 10)
        self.click_subscription = self.create_subscription(PointStamped, 'clicked_point', self.click_callback, 10)
        self.goal_publisher = self.create_publisher(PoseStamped, '/goal_pose', 10)
        self.start = False
        self.amcl = None
        self.edge_length = 0.91
        self.map_name = 'map'
        self.map = [
            # column 0, x = 0
            [
                {'coordinate': (0, 0), 'accessibility': True, 'judging_orientation': {2, 3}},
                {'coordinate': (0, 1), 'accessibility': True, 'judging_orientation': {1, 2}},
                {'coordinate': (0, 2), 'accessibility': False},
            ],
            # column 1, x = 1
            [
                {'coordinate': (1, 0), 'accessibility': True, 'judging_orientation': {0, 1, 3}},
                {'coordinate': (1, 1), 'accessibility': True, 'judging_orientation': {3}},
                {'coordinate': (1, 2), 'accessibility': True, 'judging_orientation': {1, 2}},
            ],
            # column 2, x = 2
            [
                {'coordinate': (2, 0), 'accessibility': True, 'judging_orientation': {2, 3}},
                {'coordinate': (2, 1), 'accessibility': True, 'judging_orientation': {0}},
                {'coordinate': (2, 2), 'accessibility': True, 'judging_orientation': {0, 1}},
            ],
            # column 3, x = 3
            [
                {'coordinate': (3, 0), 'accessibility': True, 'judging_orientation': {0, 3}},
                {'coordinate': (3, 1), 'accessibility': True, 'judging_orientation': {2}},
                {'coordinate': (3, 2), 'accessibility': True, 'judging_orientation': {1, 2}},
            ],
            # column 4, x = 4
            [
                {'coordinate': (4, 0), 'accessibility': True, 'judging_orientation': {2, 3}},
                {'coordinate': (4, 1), 'accessibility': True, 'judging_orientation': {1}},
                {'coordinate': (4, 2), 'accessibility': True, 'judging_orientation': {1, 3}},
            ],
            # column 5, x = 5
            [
                {'coordinate': (5, 0), 'accessibility': True, 'judging_orientation': {0, 3}},
                {'coordinate': (5, 1), 'accessibility': True, 'judging_orientation': {0}},
                {'coordinate': (5, 2), 'accessibility': True, 'judging_orientation': {0, 1}},
            ],
        ]

    def quaternion2yaw(self, q):
        return  np.arctan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))

    # update amcl
    def amcl_callback(self, msg):
        self.amcl = msg

    def set_goal(self, x, y, orientation):
        msg = PoseStamped()
        msg.header.frame_id = self.map_name
        # translating x and y to physical coordinates
        point = Point()
        point.x = x * self.edge_length + 0.5 * self.edge_length + 0.3
        point.y = y * self.edge_length + 0.5 * self.edge_length + 0.4
        point.z = 0.0
        # translating orientation to quaternion
        yaw = orientation * np.pi / 2
        quaternion = self.yaw2quaternion(yaw)

        msg.pose.position = point
        msg.pose.orientation = quaternion

        return msg

    # detect clicked point as initiating signal
    def click_callback(self, msg):
        # physical position in global frame
        current_x = msg.pose.pose.position.x
        current_y = msg.pose.pose.position.y
        current_yaw = self.quaternion2yaw(msg.pose.pose.orientation) / np.pi * 180

        # physical position in grid frame
        current_x_grid_frame = current_x - 0.3
        current_y_grid_frame = current_y - 0.4

        # physical position in block coordinates
        current_x_block = int(current_x_grid_frame / self.edge_length)
        current_y_block = int(current_y_grid_frame / self.edge_length)

        if 45 < current_yaw <= 135:
            current_orientation = 1
        elif 135 < current_yaw <= 225:
            current_yaw = 2
        elif 225 < current_yaw <= 315:
            current_yaw = 3
        else:
            current_yaw = 4

        msg = self.set_goal(current_x_block, current_y_block, current_yaw)
        self.goal_publisher.publish(msg)


def main():
    rclpy.init()
    predict_node = initiater()
    rclpy.spin(predict_node)
    predict_node.destroy_node()
    rclpy.shutdown()




