import numpy as np
import cv2

img = cv2.imread('1.jpg')
reshaped = np.reshape(img, (308*410*3))
rl = reshaped.tolist()
new_image = np.array(rl)
new_image = np.reshape(new_image, (308,410,3))
cv2.imwrite('new1.jpg',new_image)
print(new_image.shape)